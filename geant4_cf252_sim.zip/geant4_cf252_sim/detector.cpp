#include "detector.h"
#include "settings.h"
#include "he3_electric_field.h"

#include "G4Box.hh"
#include "G4Colour.hh"
#include "G4Element.hh"
#include "G4FieldManager.hh"
#include "G4IntegrationDriver.hh"
#include "G4Isotope.hh"
#include "G4LogicalVolume.hh"
#include "G4Material.hh"
#include "G4NistManager.hh"
#include "G4PVPlacement.hh"
#include "G4SubtractionSolid.hh"
#include "G4SystemOfUnits.hh"
#include "G4Tubs.hh"
#include "G4VisAttributes.hh"
#include "G4EqMagElectricField.hh"
#include "G4ClassicalRK4.hh"
#include "G4ChordFinder.hh"

#include "G4PhysicalConstants.hh"

#include <cmath>

DetectorConstruction::DetectorConstruction(const SimulationConfig& config)
    : fConfig(config)
{
}

G4VPhysicalVolume* DetectorConstruction::Construct()
{
    G4NistManager* nist = G4NistManager::Instance();

    // ================================================================
    // Materials
    // ================================================================

    G4Material* air = nist->FindOrBuildMaterial("G4_AIR");
    G4Material* copper = nist->FindOrBuildMaterial("G4_Cu");
    G4Material* polyethylene =
        nist->FindOrBuildMaterial("G4_POLYETHYLENE");

    G4Material* steel = new G4Material(
        "Steel",
        7.87 * g / cm3,
        2
    );
    steel->AddElement(nist->FindOrBuildElement("Fe"), 0.998);
    steel->AddElement(nist->FindOrBuildElement("C"), 0.002);

    // ================================================================
    // He-3 gas
    // ================================================================

    G4Isotope* He3 = new G4Isotope(
        "He3",
        2,
        3,
        3.016 * g / mole
    );

    G4Element* helium3 = new G4Element(
        "Helium3",
        "He3",
        1
    );
    helium3->AddIsotope(He3, 100.0 * perCent);

    const G4double density =
        Settings::GAS_PRESSURE * (3.016 * g / mole) /
        (Avogadro * k_Boltzmann * Settings::GAS_TEMPERATURE);

    G4Material* helium3Gas = new G4Material(
        "He3Gas",
        density,
        1,
        kStateGas,
        Settings::GAS_TEMPERATURE,
        Settings::GAS_PRESSURE
    );
    helium3Gas->AddElement(helium3, 1.0);

    // ================================================================
    // World
    // ================================================================

    G4Box* worldSolid = new G4Box(
        "World",
        25.0 * cm,
        25.0 * cm,
        25.0 * cm
    );

    G4LogicalVolume* worldLogic = new G4LogicalVolume(
        worldSolid,
        air,
        "World"
    );

    G4VPhysicalVolume* worldPhysical = new G4PVPlacement(
        nullptr,
        G4ThreeVector(),
        worldLogic,
        "World",
        nullptr,
        false,
        0,
        true
    );

    // ================================================================
    // Detector envelope
    // ================================================================

    G4Box* envelopeSolid = new G4Box(
        "Envelope",
        Settings::ENVELOPE_LENGTH_X / 2.0,
        Settings::ENVELOPE_SIZE_Y / 2.0,
        Settings::ENVELOPE_SIZE_Z / 2.0
    );

    G4LogicalVolume* envelopeLogic = new G4LogicalVolume(
        envelopeSolid,
        air,
        "Envelope"
    );

    new G4PVPlacement(
        nullptr,
        G4ThreeVector(),
        envelopeLogic,
        "Envelope",
        worldLogic,
        false,
        0,
        true
    );

    // All cylindrical detector bodies use the same local axis and are
    // rotated so their cylinder axis is the global X axis.
    G4RotationMatrix* detectorRotation = new G4RotationMatrix();
    detectorRotation->rotateY(90.0 * deg);

    // ================================================================
    // Steel side wall
    // ================================================================

    G4Tubs* steelSolid = new G4Tubs(
        "SteelTube",
        Settings::STEEL_INNER_RADIUS,
        Settings::STEEL_OUTER_RADIUS,
        Settings::STEEL_LENGTH / 2.0,
        0.0,
        360.0 * deg
    );

    G4LogicalVolume* steelLogic = new G4LogicalVolume(
        steelSolid,
        steel,
        "SteelTube"
    );

    new G4PVPlacement(
        detectorRotation,
        G4ThreeVector(),
        steelLogic,
        "SteelTube",
        envelopeLogic,
        false,
        0,
        true
    );

    // ================================================================
    // He-3 gas
    // ================================================================

    G4Tubs* gasSolid = new G4Tubs(
        "He3Cylinder",
        0.0,
        Settings::GAS_RADIUS,
        Settings::GAS_HALF_LENGTH,
        0.0,
        360.0 * deg
    );

    // Remove the central wire volume from the gas.
    G4Tubs* wireCutSolid = new G4Tubs(
        "WireCut",
        0.0,
        Settings::WIRE_RADIUS,
        Settings::WIRE_HALF_LENGTH,
        0.0,
        360.0 * deg
    );

    G4SubtractionSolid* gasMinusWire = new G4SubtractionSolid(
        "He3MinusWire",
        gasSolid,
        wireCutSolid
    );

    G4LogicalVolume* gasLogic = new G4LogicalVolume(
        gasMinusWire,
        helium3Gas,
        "He3Gas"
    );

    // ================================================================
    // Steel end disks
    // ================================================================

    // Each disk has the same thickness as the 1 mm steel wall and
    // closes the shortened gas volume at its two ends.
    G4Tubs* capSolid = new G4Tubs(
        "SteelEndCap",
        0.0,
        Settings::STEEL_INNER_RADIUS,
        Settings::STEEL_WALL_THICKNESS / 2.0,
        0.0,
        360.0 * deg
    );

    G4LogicalVolume* capLogic = new G4LogicalVolume(
        capSolid,
        steel,
        "SteelEndCap"
    );

    const G4double capCenterX =
        Settings::GAS_HALF_LENGTH +
        Settings::STEEL_WALL_THICKNESS / 2.0;

    new G4PVPlacement(
        detectorRotation,
        G4ThreeVector(-capCenterX, 0.0, 0.0),
        capLogic,
        "SteelEndCapMinus",
        envelopeLogic,
        false,
        0,
        true
    );

    new G4PVPlacement(
        detectorRotation,
        G4ThreeVector(+capCenterX, 0.0, 0.0),
        capLogic,
        "SteelEndCapPlus",
        envelopeLogic,
        false,
        1,
        true
    );

    // ================================================================
    // Copper wire
    // ================================================================

    G4Tubs* wireSolid = new G4Tubs(
        "Wire",
        0.0,
        Settings::WIRE_RADIUS,
        Settings::WIRE_HALF_LENGTH,
        0.0,
        360.0 * deg
    );

    G4LogicalVolume* wireLogic = new G4LogicalVolume(
        wireSolid,
        copper,
        "Wire"
    );

    new G4PVPlacement(
        detectorRotation,
        G4ThreeVector(),
        wireLogic,
        "Wire",
        envelopeLogic,
        false,
        0,
        true
    );

    // ================================================================
    // Polyethylene
    // ================================================================

    // PE occupies y = 0 ... T_PE.
    // Along X it is shifted by +10 mm and has a half-width 10 mm
    // larger than the detector envelope. Subtracting the envelope
    // creates the requested "cup" geometry.
    G4Box* polyethyleneBox = new G4Box(
        "PolyethyleneBox",
        Settings::PE_HALF_X,
        fConfig.peThickness / 2.0,
        Settings::PE_HALF_Z
    );

    G4SubtractionSolid* polyethyleneWithCavity =
        new G4SubtractionSolid(
            "PolyethyleneWithEnvelopeCavity",
            polyethyleneBox,
            envelopeSolid,
            nullptr,
            G4ThreeVector(-Settings::PE_SHIFT_X, -fConfig.peThickness / 2.0, 0.0)
        );

    // The subtraction above uses the relative translation of the
    // envelope solid inside the PE box coordinates.  Since the PE box
    // itself is later placed at (PE_SHIFT_X, T_PE/2, 0), the envelope
    // cavity is centered at the detector coordinates.
    G4LogicalVolume* polyethyleneLogic = new G4LogicalVolume(
        polyethyleneWithCavity,
        polyethylene,
        "Polyethylene"
    );

    new G4PVPlacement(
        nullptr,
        G4ThreeVector(
            Settings::PE_SHIFT_X,
            fConfig.peThickness / 2.0,
            0.0
        ),
        polyethyleneLogic,
        "Polyethylene",
        worldLogic,
        false,
        0,
        true
    );

    // ================================================================
    // Cf-252 sample
    // ================================================================

    G4Isotope* cf252iso = new G4Isotope(
        "Cf252",
        98,
        252,
        252.08 * g / mole
    );

    G4Element* cfEl = new G4Element(
        "Californium",
        "Cf",
        1
    );
    cfEl->AddIsotope(cf252iso, 100.0 * perCent);

    G4Material* cfMaterial = new G4Material(
        "Cf252",
        15.1 * g / cm3,
        1
    );
    cfMaterial->AddElement(cfEl, 1.0);

    // G4Tubs is defined along local Z. Rotate it to make its height
    // axis coincide with global Y.
    G4Tubs* sampleSolid = new G4Tubs(
        "Cf252Sample",
        0.0,
        Settings::SAMPLE_RADIUS,
        Settings::SAMPLE_HEIGHT / 2.0,
        0.0,
        360.0 * deg
    );

    G4RotationMatrix* sampleRotation = new G4RotationMatrix();
    sampleRotation->rotateX(90.0 * deg);

    G4LogicalVolume* sampleLogic = new G4LogicalVolume(
        sampleSolid,
        cfMaterial,
        "Cf252Sample"
    );

    const G4ThreeVector samplePosition(
        Settings::SAMPLE_X,
        fConfig.peThickness,
        Settings::SAMPLE_Z
    );

    // The source occupies the actual solid volume, while the same
    // volume is removed from the polyethylene so the two materials do
    // not overlap.
    G4SubtractionSolid* finalPolyethyleneSolid =
        new G4SubtractionSolid(
            "PolyethyleneWithSampleCavity",
            polyethyleneWithCavity,
            sampleSolid,
            sampleRotation,
            samplePosition - G4ThreeVector(
                Settings::PE_SHIFT_X,
                fConfig.peThickness / 2.0,
                0.0
            )
        );

    // Replace the PE logical volume's solid with the final solid that
    // also contains the source cavity.
    polyethyleneLogic->SetSolid(finalPolyethyleneSolid);

    new G4PVPlacement(
        sampleRotation,
        samplePosition,
        sampleLogic,
        "Cf252Sample",
        worldLogic,
        false,
        0,
        true
    );

    // ================================================================
    // Electric field inside the He-3 volume
    // ================================================================

    He3ElectricField* field = new He3ElectricField();
    G4EqMagElectricField* equation = new G4EqMagElectricField(field);

    constexpr G4int nvar = 8;

    G4ClassicalRK4* stepper = new G4ClassicalRK4(
        equation,
        nvar
    );

    G4IntegrationDriver<G4ClassicalRK4>* driver =
        new G4IntegrationDriver<G4ClassicalRK4>(
            Settings::FIELD_MIN_STEP,
            stepper,
            nvar
        );

    G4ChordFinder* chordFinder = new G4ChordFinder(driver);

    G4FieldManager* fieldManager = new G4FieldManager(
        field,
        chordFinder
    );

    gasLogic->SetFieldManager(fieldManager, true);

    // Put gas after the field setup.
    new G4PVPlacement(
        detectorRotation,
        G4ThreeVector(),
        gasLogic,
        "He3Gas",
        envelopeLogic,
        false,
        0,
        true
    );

    // ================================================================
    // Visualization attributes
    // ================================================================

    G4VisAttributes* envelopeVis = new G4VisAttributes();
    envelopeVis->SetVisibility(false);
    envelopeLogic->SetVisAttributes(envelopeVis);

    G4VisAttributes* steelVis = new G4VisAttributes(
        G4Colour(0.7, 0.7, 0.7)
    );
    steelVis->SetVisibility(true);
    steelVis->SetForceSolid(true);
    steelLogic->SetVisAttributes(steelVis);
    capLogic->SetVisAttributes(steelVis);

    G4VisAttributes* heliumVis = new G4VisAttributes(
        G4Colour(0.2, 0.8, 1.0)
    );
    heliumVis->SetVisibility(true);
    heliumVis->SetForceSolid(true);
    gasLogic->SetVisAttributes(heliumVis);

    G4VisAttributes* wireVis = new G4VisAttributes(
        G4Colour(0.9, 0.5, 0.1)
    );
    wireVis->SetVisibility(true);
    wireVis->SetForceSolid(true);
    wireLogic->SetVisAttributes(wireVis);

    G4VisAttributes* polyethyleneVis = new G4VisAttributes(
        G4Colour(0.8, 0.8, 0.2)
    );
    polyethyleneVis->SetVisibility(true);
    polyethyleneVis->SetForceSolid(true);
    polyethyleneLogic->SetVisAttributes(polyethyleneVis);

    G4VisAttributes* sampleVis = new G4VisAttributes(
        G4Colour(0.9, 0.1, 0.1)
    );
    sampleVis->SetVisibility(true);
    sampleVis->SetForceSolid(true);
    sampleLogic->SetVisAttributes(sampleVis);

    return worldPhysical;
}
