#include "primary_generator.h"
#include "settings.h"

#include "G4Event.hh"
#include "G4IonTable.hh"
#include "G4PrimaryParticle.hh"
#include "G4PrimaryVertex.hh"
#include "G4ThreeVector.hh"
#include "G4SystemOfUnits.hh"
#include "Randomize.hh"

#include <cmath>

PrimaryGeneratorAction::PrimaryGeneratorAction(G4double sampleY)
    : fSampleY(sampleY)
{
}

void PrimaryGeneratorAction::GeneratePrimaries(G4Event* event)
{
    G4ParticleDefinition* cf252 =
        G4IonTable::GetIonTable()->GetIon(98, 252, 0.0);

    const G4ThreeVector center(
        Settings::SAMPLE_X,
        fSampleY,
        Settings::SAMPLE_Z
    );

    const G4double R = Settings::SAMPLE_RADIUS;
    const G4double halfHeight = Settings::SAMPLE_HEIGHT / 2.0;

    for (G4int i = 0; i < Settings::N_IONS; ++i)
    {
        // Uniform distribution in a cylindrical sample:
        // r = R*sqrt(U), phi = 2*pi*U.
        const G4double r = R * std::sqrt(G4UniformRand());
        const G4double phi = 2.0 * CLHEP::pi * G4UniformRand();
        const G4double yOffset =
            (2.0 * G4UniformRand() - 1.0) * halfHeight;

        const G4ThreeVector pos =
            center + G4ThreeVector(
                r * std::cos(phi),
                yOffset,
                r * std::sin(phi)
            );

        G4PrimaryVertex* vertex =
            new G4PrimaryVertex(pos, 0.0 * ns);

        G4PrimaryParticle* primary =
            new G4PrimaryParticle(cf252);

        primary->SetKineticEnergy(0.0);
        vertex->SetPrimary(primary);
        event->AddPrimaryVertex(vertex);
    }
}
